#ifndef STRING_TEST_H
#define STRING_TEST_H

/*
 *  Developer note:  This is not a fully functionaly string and is not meant to be used as such.  
 *  It is merely to serve as a testing module
 */

#include <cstring>
#include <cstdlib>

typedef char mychar;

static size_t mystrlen(const mychar * str){
    unsigned int i = 0;
    for(const mychar * it = str; *it; ++it, ++i){
	   //dummy
    }
    return i;
}

class json_string {
public:
    const static size_t npos = 0xFFFFFFFF;
    json_string(void) : len(0), str(0){
	   setToCStr("", 0);
    }
    
    json_string(const mychar * meh) : len(0), str(0){
	   setToCStr(meh, mystrlen(meh));
    }
    
    json_string(const json_string & meh) : len(0), str(0){
	   setToCStr(meh.c_str(), meh.len);
    }
    
    ~json_string(void){ free(str); };
    
    json_string(unsigned int l, mychar meh) : len(0), str(0){
	   str = (mychar*)malloc((l + 1) * sizeof(mychar));
	   len = l;
	   for (unsigned int i = 0; i < l; ++i){
		  str[i] = meh;
	   }
	   str[l] = '\0';
    }
    
    void swap(json_string & meh){
	   size_t _len = len;
	   mychar * _str = str;
	   len = meh.len;
	   str = meh.str;
	   meh.len = _len;
	   meh.str = _str;
    }
    
    const mychar * c_str(void) const { return str; };
    size_t length(void) const { return len; };
    size_t capacity(void) const { return len; };
    bool empty(void) const { return len == 0; };
    
    bool operator ==(const json_string & other) const {
	   if (len != other.len) return false;
	   return memcmp(str, other.str, len * sizeof(mychar)) == 0;
    }
    
    bool operator !=(const json_string & other) const {
	   return !(*this == other);
    }
    
    const char & operator[] (size_t pos) const { return str[pos]; }
    char & operator[] ( size_t pos ){ return str[pos]; }
    
    json_string & operator = (const json_string & meh) {
	   free(str); 
	   setToCStr(meh.c_str(), meh.len);
	   return *this;
    }
    
    json_string & operator = (const mychar * meh) {
	   free(str); 
	   setToCStr(meh, mystrlen(meh));
	   return *this;
    }
    
    json_string & operator += (const json_string & other) {
	   size_t newlen = len + other.len;
	   mychar * newstr = (mychar*)malloc((newlen + 1) * sizeof(mychar));
	   memcpy(newstr, str, len * sizeof(mychar));
	   memcpy(newstr + len, other.str, (other.len + 1) * sizeof(mychar));
	   len = newlen;
	   free(str);
	   str = newstr;
	   return *this;
    }
    
    const json_string operator + (const json_string & other) const {
	   json_string result = *this;    
	   result += other;
	   return result; 
    }
    
    json_string & operator += (const mychar other) {
	   mychar temp[2] = {other, '\0'};
	   json_string temp_s(temp);
	   return (*this) += temp_s;
    }
    
    const json_string operator + (const mychar other) const {
	   json_string result = *this;    
	   result += other;
	   return result; 
    }
    
    void reserve(size_t){};  //noop, its just a test
    void clear(void){setToCStr("", 0);}
    
    json_string substr(size_t pos = 0, size_t n = npos) const {
	   json_string res(false, false, false);
	   if (n > len) n = len;
	   if (n + pos > len) n = len - pos;
	   res.setToCStr(str + pos, n);
	   res.str[n] = L'\0';
	   return res;
    }
    
    
    size_t find ( mychar c, size_t pos = 0 ) const {
	   if (pos > len) return npos;
	   for(mychar * i = str + pos; *i; ++i){
		  if (*i == c) return i - str;
	   }
	   return npos;
    }
    
    size_t find_first_not_of ( const mychar* s, size_t pos = 0 ) const {
	   if (pos > len) return npos;
	   for(mychar * i = str + pos; *i; ++i){
		  bool found = false;
		  for(const mychar * k = s; *k; ++k){
			 if (*i == *k){
				found = true;
				break;
			 }
		  }
		  if (!found) return i - str;
	   }
	   return npos;
    }
private:
    json_string(bool, bool, bool) : len(0), str(0){};
    
    void setToCStr(const mychar * st, size_t l){
	   len = l;
	   str = (mychar*)memcpy(malloc((len + 1) * sizeof(mychar)), st, (len + 1) * sizeof(mychar));
    }
    
    size_t len;
    mychar * str;
    
};

#endif
